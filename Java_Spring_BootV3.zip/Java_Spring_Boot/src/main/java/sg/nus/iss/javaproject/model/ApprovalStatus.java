package sg.nus.iss.javaproject.model;

public enum ApprovalStatus {
	applied, approved, cancelled, deleted, updated, rejected
}
