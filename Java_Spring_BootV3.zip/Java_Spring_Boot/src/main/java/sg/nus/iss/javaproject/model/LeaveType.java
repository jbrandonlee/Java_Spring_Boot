package sg.nus.iss.javaproject.model;

public enum LeaveType {
	annual,medical,compensation
}
