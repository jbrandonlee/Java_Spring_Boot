package sg.nus.iss.javaproject.service;

import sg.nus.iss.javaproject.model.Staff;

public interface StaffInterface {
	public Staff getStaffByUsername(String username);
}
